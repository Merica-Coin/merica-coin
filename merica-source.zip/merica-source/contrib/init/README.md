Sample configuration files for:
```
SystemD: mericad.service
Upstart: mericad.conf
OpenRC:  mericad.openrc
         mericad.openrcconf
CentOS:  mericad.init
macOS:   org.merica.mericad.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
