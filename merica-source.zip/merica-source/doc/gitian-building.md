Gitian building
================

This file was moved to [the MERICA Core documentation repository](https://github.com/merica-core/docs/blob/master/gitian-building.md) at [https://github.com/merica-core/docs](https://github.com/merica-core/docs).
